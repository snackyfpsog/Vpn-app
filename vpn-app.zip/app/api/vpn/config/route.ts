import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { ip, port, protocol, ovpnConfigBase64 } = await request.json()

    if (!ip || !port) {
      return NextResponse.json({ error: "IP and port required" }, { status: 400 })
    }

    console.log(`[v0] Generating OpenVPN config for ${ip}:${port}`)

    let configContent = ""

    if (ovpnConfigBase64) {
      try {
        configContent = Buffer.from(ovpnConfigBase64, "base64").toString("utf-8")
        console.log("[v0] Using real OpenVPN config from VPN Gate")
      } catch (e) {
        console.log("[v0] Failed to decode base64 config, generating default")
        configContent = generateDefaultConfig(ip, port, protocol)
      }
    } else {
      configContent = generateDefaultConfig(ip, port, protocol)
    }

    return NextResponse.json({
      success: true,
      config: configContent,
      filename: `vpn-${ip.replace(/\./g, "-")}-${port}.ovpn`,
      instructions: "Download this config and import it into your OpenVPN client",
    })
  } catch (error) {
    console.error("[v0] Error generating config:", error)
    return NextResponse.json({ error: "Failed to generate config" }, { status: 500 })
  }
}

function generateDefaultConfig(ip: string, port: number, protocol?: string) {
  return `client
dev tun
proto ${protocol?.toLowerCase() || "udp"}
remote ${ip} ${port}
resolv-retry infinite
nobind
persist-key
persist-tun
ca ca.crt
cert client.crt
key client.key
cipher AES-256-CBC
auth SHA256
comp-lzo
verb 3
mute 20
keepalive 10 120
tls-client
tls-version-min 1.2
tls-cipher TLS-DHE-RSA-WITH-AES-256-CBC-SHA:TLS-DHE-DSS-WITH-AES-256-CBC-SHA:TLS-RSA-WITH-AES-256-CBC-SHA
`
}
