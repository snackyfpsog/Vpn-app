import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { connectionId } = await request.json()

    if (!connectionId) {
      return NextResponse.json({ error: "Connection ID is required" }, { status: 400 })
    }

    console.log("[v0] Disconnecting from:", connectionId)

    // Simulate disconnection delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("[v0] Disconnected successfully")

    return NextResponse.json({
      success: true,
      message: "VPN disconnected successfully",
    })
  } catch (error) {
    console.error("[v0] Disconnection error:", error)
    return NextResponse.json({ error: "Failed to disconnect VPN" }, { status: 500 })
  }
}
