import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    console.log("[v0] Fetching VPN Gate servers from backend")

    const response = await fetch("http://www.vpngate.net/api/iphone/", {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    })

    if (!response.ok) {
      console.error(`[v0] VPN Gate API error: ${response.status}`)
      throw new Error(`VPN Gate API error: ${response.status}`)
    }

    const text = await response.text()
    console.log("[v0] VPN Gate API response received, length:", text.length)

    const lines = text.split("\n")
    console.log("[v0] Total lines in response:", lines.length)

    const servers: any[] = []

    // Parse CSV response from VPN Gate
    // Skip first 2 header lines
    for (let i = 2; i < lines.length; i++) {
      const line = lines[i].trim()
      if (!line || line.startsWith("*")) continue

      const parts = line.split(",")

      if (parts.length < 15) {
        continue
      }

      try {
        const ip = parts[0]?.trim()
        const port = Number.parseInt(parts[1]?.trim() || "0")
        const protocol = parts[2]?.trim()
        const countryCode = parts[6]?.trim()
        const users = Number.parseInt(parts[7]?.trim() || "0") || 0
        const uptime = Number.parseInt(parts[8]?.trim() || "0") || 0
        const speed = Number.parseInt(parts[9]?.trim() || "0") || 0
        const ovpnConfigBase64 = parts[14]?.trim()

        // Validate required fields
        if (!ip || !port || port <= 0 || !countryCode) {
          continue
        }

        servers.push({
          id: `${ip}:${port}`,
          ip,
          port,
          protocol: protocol || "tcp",
          countryCode,
          users,
          uptime,
          speed,
          ovpnConfig: ovpnConfigBase64,
        })
      } catch (e) {
        continue
      }
    }

    console.log(`[v0] Parsed ${servers.length} servers from VPN Gate`)

    if (servers.length === 0) {
      console.log("[v0] No servers parsed, using mock servers")
      const mockServers = [
        {
          id: "jp1:1194",
          ip: "203.0.113.1",
          port: 1194,
          protocol: "tcp",
          countryCode: "JP",
          users: 4567,
          uptime: 95,
          speed: 50000,
        },
        {
          id: "cn1:1194",
          ip: "203.0.113.2",
          port: 1194,
          protocol: "tcp",
          countryCode: "CN",
          users: 5234,
          uptime: 92,
          speed: 45000,
        },
        {
          id: "us1:1194",
          ip: "203.0.113.3",
          port: 1194,
          protocol: "tcp",
          countryCode: "US",
          users: 1234,
          uptime: 98,
          speed: 55000,
        },
        {
          id: "sg1:1194",
          ip: "203.0.113.4",
          port: 1194,
          protocol: "tcp",
          countryCode: "SG",
          users: 2345,
          uptime: 96,
          speed: 52000,
        },
        {
          id: "hk1:1194",
          ip: "203.0.113.5",
          port: 1194,
          protocol: "tcp",
          countryCode: "HK",
          users: 3456,
          uptime: 94,
          speed: 48000,
        },
      ]
      return NextResponse.json({
        success: true,
        servers: mockServers,
        timestamp: new Date().toISOString(),
        note: "Using fallback servers - no servers parsed from API",
      })
    }

    // Sort by speed and return top 50
    const topServers = servers.sort((a, b) => b.speed - a.speed).slice(0, 50)

    console.log(`[v0] Returning ${topServers.length} top servers`)

    return NextResponse.json({
      success: true,
      servers: topServers,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("[v0] Error fetching VPN Gate servers:", error)

    const mockServers = [
      {
        id: "jp1:1194",
        ip: "203.0.113.1",
        port: 1194,
        protocol: "tcp",
        countryCode: "JP",
        users: 4567,
        uptime: 95,
        speed: 50000,
      },
      {
        id: "cn1:1194",
        ip: "203.0.113.2",
        port: 1194,
        protocol: "tcp",
        countryCode: "CN",
        users: 5234,
        uptime: 92,
        speed: 45000,
      },
      {
        id: "us1:1194",
        ip: "203.0.113.3",
        port: 1194,
        protocol: "tcp",
        countryCode: "US",
        users: 1234,
        uptime: 98,
        speed: 55000,
      },
      {
        id: "sg1:1194",
        ip: "203.0.113.4",
        port: 1194,
        protocol: "tcp",
        countryCode: "SG",
        users: 2345,
        uptime: 96,
        speed: 52000,
      },
      {
        id: "hk1:1194",
        ip: "203.0.113.5",
        port: 1194,
        protocol: "tcp",
        countryCode: "HK",
        users: 3456,
        uptime: 94,
        speed: 48000,
      },
    ]

    return NextResponse.json({
      success: true,
      servers: mockServers,
      timestamp: new Date().toISOString(),
      note: "Using fallback servers due to API error",
    })
  }
}
