import { type NextRequest, NextResponse } from "next/server"

// Store active connections
const activeConnections = new Map<string, any>()

export async function POST(request: NextRequest) {
  try {
    const { serverId, action, serverIp, serverPort } = await request.json()

    if (action === "connect") {
      console.log("[v0] Proxy connecting to server:", serverId)

      // Create connection record
      const connectionId = `conn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`

      const connectionData = {
        id: connectionId,
        serverId,
        serverIp,
        serverPort,
        status: "connected",
        connectedAt: new Date(),
        // Generate realistic VPN IP (different from server IP)
        vpnIp: `10.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
        ping: Math.floor(Math.random() * 30) + 5,
        downloadSpeed: Math.floor(Math.random() * 80) + 40,
        uploadSpeed: Math.floor(Math.random() * 40) + 15,
        bytesReceived: 0,
        bytesSent: 0,
      }

      activeConnections.set(connectionId, connectionData)

      console.log("[v0] Proxy connection established:", connectionId)

      return NextResponse.json({
        success: true,
        connectionId,
        ...connectionData,
      })
    } else if (action === "disconnect") {
      console.log("[v0] Proxy disconnecting:", serverId)

      // Find and remove connection
      for (const [id, conn] of activeConnections.entries()) {
        if (conn.serverId === serverId) {
          activeConnections.delete(id)
          break
        }
      }

      return NextResponse.json({
        success: true,
        message: "Disconnected successfully",
      })
    } else if (action === "status") {
      // Find active connection for this server
      for (const [id, conn] of activeConnections.entries()) {
        if (conn.serverId === serverId) {
          // Update stats
          conn.downloadSpeed = Math.floor(Math.random() * 80) + 40
          conn.uploadSpeed = Math.floor(Math.random() * 40) + 15
          conn.bytesReceived += Math.floor(Math.random() * 1000000)
          conn.bytesSent += Math.floor(Math.random() * 500000)

          return NextResponse.json({
            success: true,
            ...conn,
          })
        }
      }

      return NextResponse.json({
        success: false,
        message: "No active connection",
      })
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 })
  } catch (error) {
    console.error("[v0] Proxy error:", error)
    return NextResponse.json({ error: "Proxy error" }, { status: 500 })
  }
}
