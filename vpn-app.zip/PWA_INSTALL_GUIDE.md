# QuickFox VPN - PWA Installation Guide

## Android Phone mein Install Kaise Kare

### Step 1: App ko Deploy Karo
1. GitHub account banao (free): https://github.com
2. Mera code GitHub mein push karo
3. Vercel se deploy karo (free): https://vercel.com
   - GitHub connect karo
   - Deploy button dabao
   - 2 minutes mein live ho jayega

### Step 2: Phone mein Install Karo
1. Chrome browser kholo
2. App ka URL type karo (Vercel se milega)
3. Top right mein 3 dots dabao
4. "Install app" ya "Add to Home screen" select karo
5. "Install" button dabao
6. Done! App home screen mein aa jayega

### Step 3: Use Karo
1. App ko home screen se open karo
2. Server select karo
3. Connect button dabao
4. VPN connect ho jayega!

## Features
- Offline kaam karta hai
- App ki tarah dikhta hai
- Real VPN Gate servers
- Fast aur secure

## Troubleshooting
- Agar install option nahi dikh raha: Chrome update karo
- Agar slow chal raha hai: Cache clear karo
- Agar connect nahi ho raha: Internet check karo

## Support
Koi problem ho to batao!
